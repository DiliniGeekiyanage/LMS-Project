package com.example.myapplication.Module.model;

public class Categoryitem {
    public String name,imageLink;

    public Categoryitem(String name, String imageLink) {
        this.name = name;
        this.imageLink = imageLink;
    }

    public Categoryitem() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImageLink() {
        return imageLink;
    }

    public void setImageLink(String imageLink) {
        this.imageLink = imageLink;
    }
}
