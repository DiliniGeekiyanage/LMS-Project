package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.core.view.GravityCompat;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class navigationbar extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{

    private AppBarConfiguration mAppBarConfiguration;

    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
//        txt=findViewById(R.id.username_revDash);
//        txt.setText("asdsd");




        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_navigationbar);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);



        mAuth=FirebaseAuth.getInstance();

    }


    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }




//

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            // Handle the camera action
            Log.d("Home","Home");
        }
        if (id == R.id.nav_profile) {
            // Handle the camera action
            Log.d("Home","Profile");
            startActivity(new Intent(navigationbar.this,profileScreen.class));
        }
        if (id == R.id.nav_support) {
            // Handle the camera action
            Log.d("Home","Support");
            startActivity(new Intent(navigationbar.this,SupportScreen.class));
        }
        if (id == R.id.logOutNavi) {
            // Handle the camera action
            Log.d("Home","logout");

            mAuth.signOut();
            startActivity(new Intent(navigationbar.this,Login.class));
            finish();


        }


        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    public void goToTimeTableAcctivity(View view) {
        startActivity(new Intent(navigationbar.this, TimeTableScreeen.class));

    }

    public void goToQrActivity(View view) {
        startActivity(new Intent(navigationbar.this,QrScanner.class));

    }

    public void goToModuleAcctivty(View view) {
        startActivity(new Intent(navigationbar.this, ModuleScreen.class));
    }

    public void goToResultActivity(View view) {
        startActivity(new Intent(navigationbar.this, ResultScreen.class));
    }
}
