package com.example.myapplication.Module.Adapater;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.Module.model.Categoryitem;
import com.example.myapplication.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class MyAdapter  extends RecyclerView.Adapter<MyAdapter.MyAdapterViewHolder> {

    public Context c;
    public ArrayList<Categoryitem> arrayList;

    public MyAdapter(Context c, ArrayList<Categoryitem> arrayList){
        this.c=c;
        this.arrayList=arrayList;

    }

    @NonNull
    @Override
    public MyAdapterViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext())
                .inflate(R.layout.category_item,parent,false);


        return new MyAdapterViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyAdapterViewHolder holder, int position) {
        Categoryitem categoryitem=arrayList.get(position);
        holder.t1.setText(categoryitem.getName());
        Picasso.get().load(categoryitem.getImageLink()).into(holder.i1);

    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }






    public class MyAdapterViewHolder extends  RecyclerView.ViewHolder{
        public TextView t1;
        public ImageView i1;
        public MyAdapterViewHolder(@NonNull View itemView) {

            super(itemView);
            t1=itemView.findViewById(R.id.nameCat);
            i1=(ImageView)itemView.findViewById(R.id.imgeCat);



        }
    }
}
