package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Login extends AppCompatActivity {

    private EditText Email, Password;
    //TextView emailREv;
    private ProgressBar progressBar;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Email = findViewById(R.id.email_login);
        Password = findViewById(R.id.password_login);
        progressBar = findViewById(R.id.progressBar2);
        mAuth = FirebaseAuth.getInstance();



    }


    public void goToRgister(View view) {
        startActivity(new Intent(Login.this, Register.class));
    }

    //-------------------------------------------Backend Login Process----------------------------------
    private void LoginUser() {

               String email, password;

        email = Email.getText().toString();
        password = Password.getText().toString();

        Log.d("Email of Login ", email);
        Log.d("Password of Login ", password);
// ---------------------------------Validation   Part------------------------------------------
        if (TextUtils.isEmpty(email)) {
            Email.setError("Email is Required !");
            return;
        }
        if (TextUtils.isEmpty(password)) {
            Password.setError("Password is Required !");
            return;
        }
        progressBar.setVisibility(View.VISIBLE);
        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(getApplicationContext(), "Login successful!", Toast.LENGTH_LONG).show();
                            progressBar.setVisibility(View.GONE);


                            startActivity(new Intent(Login.this, navigationbar.class));
                            finish();
                        } else {
                            Toast.makeText(getApplicationContext(), "Login failed! Please try again later", Toast.LENGTH_LONG).show();
                            progressBar.setVisibility(View.GONE);
                        }
                    }
                });


    }

    public void GoToDashBoadWithLogin(View view) {
        LoginUser();


//        startActivity(new Intent(Login.this,navigationbar.class));
//        finish();

    }

    public void FrogetPassword(View view) {
        Log.d("Foregt","onclick");
        final EditText resultMail= new EditText(view.getContext());
        AlertDialog.Builder passwordResetDialog=new AlertDialog.Builder(view.getContext());
        passwordResetDialog.setTitle("Reset Password ? ");
        passwordResetDialog.setMessage("Enter Your Email To Received Rest Link ");
        passwordResetDialog.setView(resultMail);

        passwordResetDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String mail=resultMail.getText().toString();
                mAuth.sendPasswordResetEmail(mail).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Toast.makeText(Login.this,"Rest Link sent To Your Email",Toast.LENGTH_SHORT).show();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(Login.this,"Error ! Link is Not Sent"+e.getMessage(),Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
        passwordResetDialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        passwordResetDialog.show();
    }
}
