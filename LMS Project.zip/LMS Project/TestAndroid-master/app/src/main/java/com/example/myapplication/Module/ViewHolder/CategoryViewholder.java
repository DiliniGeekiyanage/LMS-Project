package com.example.myapplication.Module.ViewHolder;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;

public class CategoryViewholder extends RecyclerView.ViewHolder{
   public TextView t1;
   public ImageView i1;

    public CategoryViewholder(@NonNull View itemView) {
        super(itemView);
        t1=(TextView)itemView.findViewById(R.id.nameCat);
        i1=(ImageView)itemView.findViewById(R.id.imgeCat);

    }
}
