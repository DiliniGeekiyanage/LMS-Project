package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.makeramen.roundedimageview.RoundedTransformationBuilder;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Transformation;

import java.net.URI;

public class profileScreen extends AppCompatActivity {
    TextView Email,UserName,Phone;
    FirebaseAuth mAuth;
    FirebaseFirestore fStore;
    String userID;
    ImageView profileImage;
    StorageReference storageReference;
    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_screen);
        //Toolbar toolbar = findViewById(R.id.toolbar);
        progressBar=findViewById(R.id.progressBarImageUploade);


//-------------------define user profile to retrive  data------------------------------------------------
        Phone=findViewById(R.id.phonenum_revPo);
        Email=findViewById(R.id.email_revPo);
        UserName=findViewById(R.id.username_revPro);
  //-------------------------    ----------------------
        profileImage=findViewById(R.id.pro_profile);
//-------------------------------------
        mAuth=FirebaseAuth.getInstance();
        fStore=FirebaseFirestore.getInstance();
        storageReference= FirebaseStorage.getInstance().getReference();
//-------------------most import part to Time tabel-----------------------------------------------------------------
        final Transformation transformation = new RoundedTransformationBuilder()

                .cornerRadiusDp(70)

                .oval(false)
                .build();


        StorageReference profileRef=storageReference.child("Users/"+mAuth.getCurrentUser().getUid()+"/Profile.jpg");
        profileRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {
                Picasso.get().load(uri)
                        .transform(transformation)
                        .resize(100, 100)
                        .into(profileImage);
                progressBar.setVisibility(View.INVISIBLE);
            }
        });
//------------------------above code most import part to Time tabel-----------------------------------------------------------------
        userID=mAuth.getCurrentUser().getUid();
 //----------------------------retrive data from firebase and store to profile xml------------------------------------------

        final DocumentReference documentReference=fStore.collection("Users").document(userID);

        documentReference.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException e) {
                Phone.setText(documentSnapshot.getString("Phone Number"));
                UserName.setText(documentSnapshot.getString("User Name"));
                Email.setText(documentSnapshot.getString("Email"));

                Log.d("documentation of ",documentSnapshot.getString("Email"));
            }
        });


    }

    public void changeprofileImage(View view) {
        //open gallery

        Intent OpenGalleryIntent= new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(OpenGalleryIntent,1000);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode== 1000){
            if(resultCode == Activity.RESULT_OK){
                Uri imageUri=data.getData();
               // profileImage.setImageURI(imageUri);


                uploadImageTodirebase(imageUri);

            }

        }

    }

    private void uploadImageTodirebase(Uri imageUri) {

        //uploade image to firebase storage
        final StorageReference fileRef=storageReference.child("Users/"+mAuth.getCurrentUser().getUid()+"/Profile.jpg");
        fileRef.putFile(imageUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                progressBar.setVisibility(View.VISIBLE);
                Toast.makeText(profileScreen.this,"Image Uploaded",Toast.LENGTH_SHORT).show();
                //retriving
                fileRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(Uri uri) {
                        Picasso.get().load(uri).into(profileImage);
                        progressBar.setVisibility(View.GONE);
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(profileScreen.this,"Image Not Retive !",Toast.LENGTH_SHORT).show();
                    }
                });

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(profileScreen.this,"Image Uploaded is Failed",Toast.LENGTH_SHORT).show();
            }
        });

    }
}


