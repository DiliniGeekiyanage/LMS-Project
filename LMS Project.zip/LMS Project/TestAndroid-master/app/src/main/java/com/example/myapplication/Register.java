package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class Register extends AppCompatActivity {

    private EditText Username,Email,Phone,Password;
    private ProgressBar progressBar;
    private FirebaseAuth mAuth;
    private FirebaseFirestore fStore;
    private String userID;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        Username=findViewById(R.id.username_reg);
        Email=findViewById(R.id.email_reg);
        Phone=findViewById(R.id.phonenum_reg);
        Password=findViewById(R.id.password_reg);
        progressBar=findViewById(R.id.progressReg);

        mAuth = FirebaseAuth.getInstance();
        fStore=FirebaseFirestore.getInstance();
    }

    public void goToLogin(View view) {
        startActivity(new Intent(Register.this,Login.class));
        finish();
    }

    private void register(){

        final String email,password,phone,username;

        email = Email.getText().toString();
        phone = Phone.getText().toString();
        username = Username.getText().toString();
        password = Password.getText().toString();

//        Log.d("username of Register ",username);
//        Log.d("Email of Register ",email);
//        Log.d("phone of Register ",phone);
//        Log.d("Password of Register ",password);

 // ---------------------------------Validation  ---------------------------------------
        if (TextUtils.isEmpty(username)) {
            Username.setError("UserName is Required !");
            return;
        }
        if (TextUtils.isEmpty(email)) {
            Email.setError("Email is Required !");
            return;
        }

        if (TextUtils.isEmpty(phone)) {
            Phone.setError("Phone Number is Required !");
            return;
        }
        if (TextUtils.isEmpty(password)) {
            Password.setError("Password is Required !");
            return;
        }
//-------------------------------------------------------------------------------------
        progressBar.setVisibility(View.VISIBLE);

        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(getApplicationContext(), "Register successful!", Toast.LENGTH_LONG).show();
                            progressBar.setVisibility(View.GONE);
                            //---------get current user------------
                        userID=mAuth.getCurrentUser().getUid();

                            //----firebasefireStore --------------------------
                            DocumentReference documentReference=fStore.collection("Users").document(userID);

                            Map<String,Object> user=new HashMap<>();
                            user.put("User Name",username);
                            user.put("Email",email);
                            user.put("Phone Number",phone);

                            documentReference.set(user).addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                Log.d("TAG","ON Success :user Profile is Create for "+userID);
                                }
                            }).addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Log.d("TAG"," UnSuccess :user Profile is Create for "+userID);
                                }
                            });

                           startActivity(new Intent(Register.this, Login.class));

                        }
                        else {
                            Toast.makeText(getApplicationContext(), "Register failed! Please try again later", Toast.LENGTH_LONG).show();
                            progressBar.setVisibility(View.GONE);
                        }
                    }
                });


    }
    public void Register(View view) {
        register();
    }
}
